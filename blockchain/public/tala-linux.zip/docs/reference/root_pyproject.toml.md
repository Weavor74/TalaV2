# File: `pyproject.toml`

## Overview

The Python project configuration. Defines the 'tala_engine' package, dependencies, and build system requirements.

## File Contents

```toml
[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "tala-engine"
version = "0.1.19"
description = "Tala Cognitive Engine Room — local AI orchestration shell"
authors = [
  { name="Tala Project" }
]
readme = "README.md"
requires-python = ">=3.10"
dependencies = [
    "websockets==16.0",
    "asyncpg==0.31.0",
    "markdown==3.10.2",
    "PyYAML==6.0.3",
    "tiktoken==0.13.0",
    "python-dotenv==1.2.2",
    "pydantic==2.13.4",
    "openai==2.44.0",
    "google-generativeai==0.8.6",
    "textual==8.2.7",
    "rich==15.0.0",
    "mcp==1.28.0",
    "click==8.4.2",
    "httpx-sse==0.4.3",
    "cryptography==49.0.0",
    "chromadb==1.5.9",
    "pyautogui==0.9.54",
    "Pillow==12.2.0",
    "mnemonic==0.21",
    "aiortc==1.14.0",
    "lxml==6.1.1",
]

[project.optional-dependencies]
test = [
    "pytest==9.1.1",
    "pytest-asyncio==1.4.0"
]
transformers = [
    "transformers==5.12.1",
    "accelerate==1.14.0",
    "sentencepiece==0.2.1",
]
vllm = [
    "vllm>=0.5.0",
]
llamacpp = [
    "llama-cpp-python>=0.2.79",
]
voice = [
    "openai-whisper>=20231117",
    "sounddevice>=0.4.6",
    "numpy>=1.26.0,<2.5.0",
]
mem0 = [
    "mem0ai>=0.1.29",
]
astrology = [
    "pyswisseph>=2.10.3.2",
]

[project.scripts]
tala = "cli.main:main"
tala-tui = "cli.tui:main"

[tool.setuptools]
package-dir = {"" = "python"}
packages = ["cli", "harness", "inference", "astrology"]

```

# File: `tala_self_test.py`

## Contents

*No classes or functions defined in this file. It may be a configuration or script file.*

## Source Code

```python
from __future__ import annotations

import sys
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from python.harness.self_test import main


if __name__ == "__main__":
    raise SystemExit(main())

```

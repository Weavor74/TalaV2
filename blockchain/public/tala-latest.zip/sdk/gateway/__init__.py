"""
Gateway & MCP runtime module
"""

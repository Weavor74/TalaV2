# File: `run.ps1`

## Overview

This is a shell/automation script.

## File Contents

```powershell
Start-Sleep -Seconds 10

```

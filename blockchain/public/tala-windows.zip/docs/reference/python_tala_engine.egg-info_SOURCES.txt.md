# File: `SOURCES.txt`

## Overview

This is a text or documentation file.

## File Contents

```text
README.md
pyproject.toml
python/astrology/__init__.py
python/astrology/ephemeris.py
python/astrology/style_cap.py
python/astrology/synastry.py
python/cli/__init__.py
python/cli/main.py
python/cli/tui.py
python/harness/__init__.py
python/harness/config.py
python/harness/db.py
python/harness/e2ee_manager.py
python/harness/guardrails_manager.py
python/harness/heartbeat_scheduler.py
python/harness/mcp_manager.py
python/harness/mem0_adapter.py
python/harness/memory.py
python/harness/multimodal.py
python/harness/retrieval.py
python/harness/search_manager.py
python/harness/self_test.py
python/harness/server.py
python/harness/settings_nn.py
python/harness/skill_distiller.py
python/harness/sync_manager.py
python/harness/token_counter.py
python/harness/wallet.py
python/harness/webrtc_manager.py
python/harness/workflow_executor.py
python/harness/workflows_util.py
python/inference/__init__.py
python/inference/embedded_engine.py
python/inference/vllm_engine.py
python/tala_engine.egg-info/PKG-INFO
python/tala_engine.egg-info/SOURCES.txt
python/tala_engine.egg-info/dependency_links.txt
python/tala_engine.egg-info/entry_points.txt
python/tala_engine.egg-info/requires.txt
python/tala_engine.egg-info/top_level.txt
tests/test_command_parser.py
tests/test_gateway.py
tests/test_mcp_manager.py
tests/test_memory.py
tests/test_memory_providers.py
tests/test_multimodal.py
tests/test_promptware.py
tests/test_semantic_rag.py
tests/test_trust.py
tests/test_workflow_skill_distillation.py
tests/test_workflow_terminal_backends.py
```

"""
Gateway & MCP runtime module
"""
